from abc import ABCMeta


class Entity(object):
    __metaclass__ = ABCMeta
